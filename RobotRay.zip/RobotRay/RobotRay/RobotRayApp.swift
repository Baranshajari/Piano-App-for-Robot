//
//  RobotRayApp.swift
//  RobotRay
//
//  Created by Leonard Chan on 11/11/24.
//

import SwiftUI

@main
struct RobotRayApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}
