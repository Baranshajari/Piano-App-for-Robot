//
//  StartView.swift
//  RobotRay
//
//  Created by Leonard Chan on 11/11/24.
//

import SwiftUI

struct StartView: View {
    var body: some View {
        NavigationView {
            NavigationLink("Start", destination: TunerView())
        }.navigationViewStyle(.stack)
    }
}

#Preview {
    StartView()
}
