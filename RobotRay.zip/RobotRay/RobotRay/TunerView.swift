//
//  TunerView.swift
//  RobotRay
//
//  Created by Leonard Chan on 11/11/24.
//

import SwiftUI
import AudioKit
import AudioKitEX
import AudioKitUI
import AudioToolbox
import SoundpipeAudioKit
import AVFAudio

struct TunerData {
    var pitch: Float = 0.0
    var amplitude: Float = 0.0
    var noteNameWithSharps = "-"
    var noteNameWithFlats = "-"
}

class TunerConductor: ObservableObject, HasAudioEngine {
    @Published var data = TunerData()

    let engine = AudioEngine()
    let initialDevice: Device

    let mic: AudioEngine.InputNode
    let tappableNodeA: Fader
    let tappableNodeB: Fader
    let tappableNodeC: Fader
    let silence: Fader

    var tracker: PitchTap!

    let noteFrequencies = [16.35, 17.32, 18.35, 19.45, 20.6, 21.83, 23.12, 24.5, 25.96, 27.5, 29.14, 30.87]
    let noteNamesWithSharps = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"]
    let noteNamesWithFlats = ["C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B"]

    init() {
        guard let input = engine.input else { fatalError() }

        guard let device = engine.inputDevice else { fatalError() }

        initialDevice = device

        mic = input
        tappableNodeA = Fader(mic)
        tappableNodeB = Fader(tappableNodeA)
        tappableNodeC = Fader(tappableNodeB)
        silence = Fader(tappableNodeC, gain: 0)
        engine.output = silence

        tracker = PitchTap(mic) { pitch, amp in
            DispatchQueue.main.async {
                self.update(pitch[0], amp[0])
            }
        }
        tracker.start()
    }

    func update(_ pitch: AUValue, _ amp: AUValue) {
        // Reduces sensitivity to background noise to prevent random / fluctuating data.
        guard amp > 0.1 else { return }

        data.pitch = pitch
        data.amplitude = amp

        var frequency = pitch
        while frequency > Float(noteFrequencies[noteFrequencies.count - 1]) {
            frequency /= 2.0
        }
        while frequency < Float(noteFrequencies[0]) {
            frequency *= 2.0
        }

        var minDistance: Float = 10000.0
        var index = 0

        for possibleIndex in 0 ..< noteFrequencies.count {
            let distance = fabsf(Float(noteFrequencies[possibleIndex]) - frequency)
            if distance < minDistance {
                index = possibleIndex
                minDistance = distance
            }
        }
        let octave = Int(log2f(pitch / frequency))
        data.noteNameWithSharps = "\(noteNamesWithSharps[index])\(octave)"
        data.noteNameWithFlats = "\(noteNamesWithFlats[index])\(octave)"
    }
}

struct TunerView: View {
    @StateObject var conductor = TunerConductor()

    var body: some View {
        VStack {
            VStack {
                HStack {
                    Text("Frequency")
                    Spacer()
                    Text("\(conductor.data.pitch, specifier: "%0.1f")")
                }

                HStack {
                    Text("Amplitude")
                    Spacer()
                    Text("\(conductor.data.amplitude, specifier: "%0.1f")")
                }

                HStack {
                    Text("Note Name")
                    Spacer()
                    Text("\(conductor.data.noteNameWithSharps) / \(conductor.data.noteNameWithFlats)")
                }
                
                Spacer()
            }
            
            MatcherView(conductor: conductor)
            
            InputDevicePicker(device: conductor.initialDevice)
        }
        .onAppear {
            conductor.start()
        }
        .onDisappear {
            conductor.stop()
        }
    }
}

struct MatcherView: View {
    @ObservedObject var conductor: TunerConductor
    @State private var expectedNotes = ["C", "D", "E", "F", "C", "D", "E", "F", "C", "D", "E", "F", "E", "D", "C", "D", "E", "F"]  // Sequence of notes
    @State private var currentIndex = 0
    @State private var backgroundColor: Color = .clear  // Background color state
    @StateObject private var speechManager = SpeechManager()
    
    var body: some View {
        VStack {
            Text("Play this note:")
                .font(.title)
            
            // Display the current expected note with dynamic background color
            Text(expectedNotes[currentIndex])
                .font(.largeTitle)
                .padding()
                .background(backgroundColor)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray, lineWidth: 1)
                )
        }
        .onChange(of: conductor.data.noteNameWithSharps) { newNote in
            handleNotePress(newNote)
        }
        .onAppear {
            speechManager.queueSpeech("Let's start playing!")
        }
    }

    func handleNotePress(_ newNote: String) {
        if newNote.starts(with: expectedNotes[currentIndex]) {
            // Correct note: set background to green
            backgroundColor = .green
            speechManager.queueSpeech("Great job, keep going!")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                backgroundColor = .clear
                currentIndex = (currentIndex + 1) % expectedNotes.count  // Move to the next note
            }
        } else {
            // Incorrect note: set background to red
            backgroundColor = .red
            speechManager.queueSpeech("Let's try again!")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                backgroundColor = .clear  // Reset background after a delay
            }
        }
    }
}

struct InputDevicePicker: View {
    @State var device: Device

    var body: some View {
        Picker("Input: \(device.deviceID)", selection: $device) {
            ForEach(getDevices(), id: \.self) {
                Text($0.deviceID)
            }
        }
        .pickerStyle(MenuPickerStyle())
        .onChange(of: device, perform: setInputDevice)
    }

    func getDevices() -> [Device] {
        AudioEngine.inputDevices.compactMap { $0 }
    }

    func setInputDevice(to device: Device) {
        do {
            try AudioEngine.setInputDevice(device)
        } catch let err {
            print(err)
        }
    }
}


#Preview {
    TunerView()
}

class SpeechManager: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    private let speechSynthesizer = AVSpeechSynthesizer()
    @Published var isSpeaking = false  // Track speaking state

    override init() {
        super.init()
        speechSynthesizer.delegate = self
    }

    func queueSpeech(_ text: String) {
        // Only speak if not currently speaking
        if !isSpeaking {
            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
            speechSynthesizer.speak(utterance)
            isSpeaking = true  // Set flag to indicate speaking state
        }
    }

    // Delegate method to reset isSpeaking flag when speech finishes
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        isSpeaking = false
        print("Finished speaking: \(utterance.speechString)")
    }
}
